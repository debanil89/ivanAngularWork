import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-takahe',
  templateUrl: './takahe.component.html',
  styleUrls: ['./takahe.component.scss']
})
export class TakaheComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}