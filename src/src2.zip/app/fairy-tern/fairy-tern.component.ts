import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fairy-tern',
  templateUrl: './fairy-tern.component.html',
  styleUrls: ['./fairy-tern.component.scss']
})
export class FairyTernComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}