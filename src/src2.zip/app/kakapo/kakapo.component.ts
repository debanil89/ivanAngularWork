import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kakapo',
  templateUrl: './kakapo.component.html',
  styleUrls: ['./kakapo.component.scss']
})
export class KakapoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}